# Angular Minimal Application Shell
Minimal Angular Application Shell with builtin Foundation that loads a single Mango Application.

Must have systemjs version 0.21.4 installed
`"systemjs": "^0.21.4"`