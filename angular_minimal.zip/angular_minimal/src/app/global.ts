export class GlobalConstants {
    public static ApplicationInstanceKey: string = "emgrn11ak";
}